// Servidor estático mínimo para probar PULSO en localhost.
// No crea cuentas ni guarda datos: la aplicación persiste en el navegador.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, process.argv.includes('--dist') ? 'dist' : '.');
const rootPath = root + path.sep;
const types = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8', '.webmanifest': 'application/manifest+json',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg'
};

http.createServer((req, res) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  let pathname;
  try { pathname = decodeURIComponent(new URL(req.url, 'http://localhost').pathname); }
  catch { res.writeHead(400).end('Solicitud inválida'); return; }
  if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405).end('Método no permitido'); return; }

  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const file = path.resolve(root, relative);
  if (!file.startsWith(rootPath)) { res.writeHead(403).end('No permitido'); return; }
  fs.readFile(file, (error, data) => {
    if (error) { res.writeHead(error.code === 'ENOENT' ? 404 : 500).end('No se encontró el archivo'); return; }
    res.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    if (req.method === 'HEAD') res.end(); else res.end(data);
  });
}).listen(Number(process.env.PORT) || 8000, '127.0.0.1', () => {
  console.log(`PULSO está en http://localhost:${Number(process.env.PORT) || 8000} — Ctrl+C para cerrar.`);
});
