(() => {
'use strict';
const P = {
'arrow-left':'<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>','arrow-right':'<path d="M5 12h14"/><path d="m12 5 7 7-7 7"/>','check':'<path d="M20 6 9 17l-5-5"/>','menu':'<path d="M4 6h16M4 12h16M4 18h16"/>',
'asterisk':'<path d="M12 6v12"/><path d="M17.2 9 6.8 15"/><path d="m6.8 9 10.4 6"/>','user-round':'<circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/>',
'sun':'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M6.3 17.7l-1.4 1.4M19.1 4.9l-1.4 1.4"/>',
'heart':'<path d="M19 14c1.5-1.5 3-3.200 3-5.500A5.500 5.500 0 0 0 16.500 3c-1.800 0-3 .5-4.500 2-1.500-1.500-2.700-2-4.500-2A5.500 5.500 0 0 0 2 8.500c0 2.300 1.500 4 3 5.500l7 7Z"/>',
'house':'<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .7-1.500l7-6a2 2 0 0 1 2.600 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
'calendar-days':'<path d="M8 2v4M16 2v4M3 10h18M8 14h.01M12 14h.01M16 14h.01M8 18h.01M12 18h.01M16 18h.01"/><rect width="18" height="18" x="3" y="4" rx="2"/>',
'clock-3':'<circle cx="12" cy="12" r="10"/><path d="M12 6v6h4.500"/>','circle-check':'<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
'notebook-pen':'<path d="M13.400 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7.400M2 6h4M2 10h4M2 14h4M2 18h4"/><path d="M21.400 5.600a1 1 0 0 0-3-3l-5 5a2 2 0 0 0-.5.900l-.8 2.900a.5.5 0 0 0 .6.600l2.900-.8a2 2 0 0 0 .9-.5z"/>',
'message-circle-heart':'<path d="M7.900 20A9 9 0 1 0 4 16.100L2 22Z"/><path d="M15.800 9.200a2.500 2.500 0 0 0-3.500 0l-.3.400-.3-.4a2.500 2.500 0 0 0-3.500 3.500L12 16.600l3.800-3.900a2.500 2.500 0 0 0 0-3.500Z"/>',
'sparkles':'<path d="M9.900 15.500A2 2 0 0 0 8.500 14.100l-6.100-1.600a.5.5 0 0 1 0-1l6.100-1.600A2 2 0 0 0 9.900 8.500l1.600-6.100a.5.5 0 0 1 1 0l1.600 6.100a2 2 0 0 0 1.400 1.400l6.100 1.600a.5.5 0 0 1 0 1l-6.100 1.600a2 2 0 0 0-1.400 1.400l-1.600 6.100a.5.5 0 0 1-1 0zM20 3v4M22 5h-4M4 17v2M5 18H3"/>',
'wind':'<path d="M12.800 19.600A2 2 0 1 0 14 16H2M17.500 8a2.500 2.500 0 1 1 2 4H2M9.800 4.400A2 2 0 1 1 11 8H2"/>',
'footprints':'<path d="M4 16v-2.400C4 11.500 3 10.500 3 8c0-2.700 1.500-6 4.500-6C9.400 2 10 3.800 10 5.500c0 3.100-2 5.700-2 8.700V16a2 2 0 1 1-4 0ZM20 20v-2.400c0-2.100 1-3.100 1-5.600 0-2.700-1.500-6-4.500-6C14.600 6 14 7.800 14 9.500c0 3.100 2 5.700 2 8.700V20a2 2 0 1 0 4 0ZM16 17h4M4 13h4"/>',
'coffee':'<path d="M10 2v2M14 2v2M6 2v2M16 8a1 1 0 0 1 1 1v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V9a1 1 0 0 1 1-1h14a4 4 0 1 1 0 8h-1"/>',
'circle-alert':'<circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>','cloud-off':'<path d="m2 2 20 20M5.800 5.800A7 7 0 0 0 9 19h8.500a4.500 4.500 0 0 0 1.300-.2M21.500 16.500A4.500 4.500 0 0 0 17.500 10h-1.800A7 7 0 0 0 10 5.100"/>',
'bookmark-check':'<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/><path d="m9 10 2 2 4-4"/>','pencil':'<path d="M21.200 6.800a1 1 0 0 0-4-4L3.800 16.200a2 2 0 0 0-.5.800l-1.300 4.400a.5.5 0 0 0 .6.600l4.400-1.300a2 2 0 0 0 .8-.5z"/><path d="m15 5 4 4"/>',
'heart-handshake':'<path d="M19 14c1.500-1.500 3-3.200 3-5.500A5.500 5.500 0 0 0 16.500 3c-1.800 0-3 .5-4.500 2-1.500-1.500-2.700-2-4.500-2A5.500 5.500 0 0 0 2 8.500c0 2.300 1.500 4 3 5.500l7 7Z"/><path d="M12 5 9 8a2.200 2.200 0 0 0 0 3.100c.8.800 2.100.9 3 .1l2.100-1.900a2.800 2.800 0 0 1 3.800 0l3 2.700"/>',
'cloud-sun':'<path d="M12 2v2M4.900 4.900l1.400 1.400M20 12h2M19.100 4.900l-1.400 1.400M15.900 12.700a4 4 0 0 0-5.900-4.200"/><path d="M13 22H7a5 5 0 1 1 4.900-6H13a3 3 0 0 1 0 6Z"/>'};
const ic = (n, s = 20) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n]}</svg>`;

const MS = 'ene feb mar abr may jun jul ago sep oct nov dic'.split(' ');
const MF = 'enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre'.split(' ');
const DW = 'domingo lunes martes miércoles jueves viernes sábado'.split(' ');
const cap = s => s[0].toUpperCase() + s.slice(1), pad = n => String(n).padStart(2, '0');
const key = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const short = d => `${d.getDate()} ${MS[d.getMonth()]} ${d.getFullYear()}`, hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
const historyDate = k => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };

const R = [
 {id:1, a:1, b:3, label:'Día difícil', icon:'heart-handshake', phrase:'un día difícil', t:'Hoy no fue fácil. No tenés que poder con todo.', d:'Un gesto pequeño puede acompañarte mañana. Elegí lo que te haga bien.'},
 {id:2, a:4, b:6, label:'Día regular', icon:'cloud-sun', phrase:'un día regular', t:'Hay días que se sienten así.', d:'No hace falta cambiarlo todo. Mañana podés empezar por algo simple.'},
 {id:3, a:7, b:8, label:'Día bueno', icon:'sun', phrase:'un buen día', t:'Lo bueno también merece su pausa.', d:'Hoy fue un buen día. Reconocé lo que te hizo bien y llevate un poquito a mañana.'},
 {id:4, a:9, b:10, label:'Día excelente', icon:'sparkles', phrase:'un día excelente', t:'¡Qué lindo que hoy se haya sentido así!', d:'Disfrutá este momento. Reconocé los hábitos que te ayudaron y compartí esa energía.'}];
const rec = (id, icon, name, desc, min) => ({id, icon, name, desc, min});
const POOL = {
 1:[
  rec('espejo','heart','Tres cosas lindas al espejo','Al levantarte, decite en voz alta tres cosas positivas sobre vos.',3), rec('resp','wind','Cinco minutos de respiración','Respirá profundo y despacio antes de empezar el día.',5), rec('charla','message-circle-heart','Hablá con alguien de confianza','Contale a una persona querida cómo te sentiste.',15), rec('paseo','footprints','Caminata corta al aire libre','Salí un rato, a tu propio ritmo.',15), rec('uno','notebook-pen','Una sola cosa pequeña','Elegí una tarea chica y cumplila, sin exigirte más.',10),
  rec('ducha-reinicio','coffee','Ducha de reinicio','Dejá que el agua tibia te ayude a soltar el peso del día anterior, sin apuro ni presiones.',10), rec('rincon-ordenado','bookmark-check','Desorden cero en un rincón','Ordená un espacio muy chico, como la mesa de noche o un cajón, para recuperar sensación de control.',5), rec('escribi-solta','notebook-pen','Escribí y soltá','Volcá en un papel todo lo que te abruma. Después, rompelo o tiralo para aliviar la carga mental.',15), rec('sonido-reconfortante','heart','Sonido reconfortante','Escuchá ruido blanco, lluvia o música instrumental suave antes de arrancar la jornada.',10), rec('luz-ventana','sun','Luz de ventana','Abrí la ventana y tomá tres minutos de aire fresco apenas te levantes.',3), rec('pie-izquierdo','notebook-pen','Empezá con el pie derecho','Durante el desayuno, anotá los puntos positivos de tu día. Siempre hay algo bueno.',15)
 ],
 2:[
  rec('grat','notebook-pen','Tres cosas por agradecer','Anotá tres cosas, por pequeñas que sean.',5), rec('music','heart','Tu playlist favorita','Escuchala mientras te preparás o viajás.',10), rec('mov','footprints','Movete un ratito','Hacé una actividad física que disfrutes.',20), rec('plan','notebook-pen','Tres prioridades para mañana','Planificalas esta noche y dejá lo demás.',5), rec('hobby','coffee','Un rato sin pantallas','Dedicáselo a un pasatiempo que te guste.',30),
  rec('estiramiento-express','wind','Estiramiento express','Desperezá cuello, espalda y piernas para aflojar la tensión acumulada en el cuerpo.',5), rec('ritual-sin-pantallas','coffee','Ritual sin pantallas','Prepará un desayuno o merienda prestando atención a los sabores y sin mirar el celular.',15), rec('cambio-aire','cloud-sun','Cambio de aire','Pasá un bloque de trabajo o descanso en un espacio distinto al habitual, como otro ambiente, patio o balcón.',20), rec('reencuadre','sparkles','Reencuadre de perspectiva','Anotá una molestia de ayer y encontrale un aspecto neutro o una enseñanza pequeña.',5), rec('escritorio-cero','bookmark-check','Escritorio en cero','Ordená la mesa de trabajo o cerrá pestañas acumuladas en la computadora antes de empezar.',5), rec('hidratacion-arranque','heart','Hidratación de arranque','Tomá un vaso grande de agua apenas te levantes para empezar el día.',2), rec('gusto-favorito','heart','Panza llena, corazón contento','Prepará o comprá eso que tanto te gusta y disfrutalo como quieras.',10)
 ],
 3:[
  rec('guardar','notebook-pen','Guardá lo que salió bien','Anotá un momento de hoy que te gustaría repetir mañana.',5), rec('gracias','message-circle-heart','Mandá un gracias','Escribile a alguien que hizo tu día un poco mejor.',3), rec('nuevo','sparkles','Probá algo nuevo','Elegí una actividad pequeña que te dé curiosidad.',10), rec('meta','sun','Una meta para mañana','Elegí una y celebrala cuando la cumplas.',5),
  rec('manana-fluida','calendar-days','Mañana fluida','Dejá el espacio listo y lo necesario separado la noche anterior para arrancar sin apuros ni decisiones extra.',10), rec('curiosidad-marcha','sparkles','Curiosidad en marcha','Leé un artículo, escuchá un fragmento de podcast o mirá un video sobre un tema nuevo que te interese.',15), rec('plan-agenda','calendar-days','Plan en agenda','Agendá una salida corta, un café o una llamada con alguien que te sume buena energía.',5), rec('recompensa-deliberada','heart','Recompensa deliberada','Tomate un tiempo para disfrutar un pequeño gusto personal sin culpa ni distracciones.',15), rec('manos-obra','pencil','Manos a la obra','Dedicá un rato a un pasatiempo manual o creativo fuera de la tecnología.',20)
 ],
 4:[
  rec('habitos','notebook-pen','Anotá qué te ayudó','Registrá los hábitos que hicieron tan bueno este día.',5), rec('compartir','message-circle-heart','Compartí tu buen día','Contáselo a alguien cercano.',5), rec('amable','heart','Algo amable por alguien','Un gesto chico que le alegre el día a otra persona.',10), rec('desafio','sparkles','Un pequeño desafío','Fijate uno para mantener el impulso.',10),
  rec('yo-futuro','notebook-pen','Mensaje a tu yo futuro','Escribí unas líneas sobre por qué te sentís tan bien hoy para releerlas en un día difícil. Podés usar «Mi espacio» en PULSO.',5), rec('alto-impacto','sparkles','Bloque de alto impacto','Aprovechá tu claridad y energía para avanzar en un proyecto importante.',30), rec('reconocimiento-externo','heart','Reconocimiento externo','Dejá un mensaje de agradecimiento o un elogio sincero a alguien por su trabajo o ayuda. ¡Compartí tu buen día!',3), rec('comparti-truco','message-circle-heart','Compartí un truco','Contale a un colega o amigo una herramienta o hábito que te esté funcionando bien. Ayudar a otros también nos ayuda.',10), rec('nueva-creacion','pencil','Nueva creación','Diseñá, escribí, probá una receta o armá algo usando tu estado de inspiración.',25)
 ]};
const GEN = [rec('afloja-cuerpo','wind','Aflojá el cuerpo','Hacé una pausa corta para acomodar la postura, destrabar la mandíbula y soltar tensión.',3), rec('limpieza-digital','bookmark-check','Limpieza digital express','Borrá capturas de pantalla viejas o fotos duplicadas del celular.',5), rec('pausa-vista','sun','Pausa de vista','Mirá por la ventana a un punto lejano para descansar los ojos de las pantallas.',2), rec('caminata-lenta','footprints','Caminata a ritmo lento','Salí a dar una vuelta a la manzana prestando atención a los sonidos del entorno. Aprovechá para pensar con claridad.',10)];
const ALL = Object.fromEntries([...Object.values(POOL).flat(), ...GEN].map(r => [r.id, r]));
const rangeOf = n => R.find(r => n >= r.a && n <= r.b);

const blankData = () => ({entries: {}, letters: []});
const normalizeData = data => ({entries: data?.entries && typeof data.entries === 'object' ? data.entries : {}, letters: Array.isArray(data?.letters) ? data.letters : []});
let DB = blankData();
try {
  const guestData = normalizeData(JSON.parse(localStorage.getItem('pulso.guest.v1') || localStorage.getItem('pulso.v1')));
  const lastUser = JSON.parse(localStorage.getItem('pulso.last-user') || 'null');
  const accountData = lastUser ? normalizeData(JSON.parse(localStorage.getItem(`pulso.user.${lastUser.id}`) || 'null')) : blankData();
  DB = {entries:{...accountData.entries,...guestData.entries},letters:[...new Map([...accountData.letters,...guestData.letters].map(letter=>[letter.id,letter])).values()]};
} catch (e) {}
const persist = () => {
  try { const data = JSON.stringify(DB); localStorage.setItem('pulso.v1', data); localStorage.setItem('pulso.guest.v1', data); return true; }
  catch (e) { return false; }
};
const today = () => DB.entries[key(new Date())];
const S = {screen:'home', pick:7, bad:null, sel:new Set(), letterId:null, letterDraft:'', noteDraft:'', historyMode:'list'};
const $ = s => document.querySelector(s);
const esc = value => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

function pickRecs(range) {
  const seen = new Set(), now = new Date();
  for (let i = 1; i <= 3; i++) { const e = DB.entries[key(new Date(now.getFullYear(), now.getMonth(), now.getDate() - i))]; if (e && !e.general) e.ids.forEach(x => seen.add(x)); }
  const ids = POOL[range.id].filter(r => !seen.has(r.id)).slice(0, 3).map(r => r.id);
  return ids.length ? {general:false, ids} : {general:true, ids:GEN.map(r => r.id)};
}
function saveToday(score, note) {
  const range = rangeOf(score), p = pickRecs(range);
  DB.entries[key(new Date())] = {score, note:note.slice(0, 20), at:new Date().toISOString(), range:range.id, ids:p.ids, general:p.general, commit:[]};
  S.sel = new Set();
}

const brand = () => `<div class="brand"><span class="emblem">${ic('asterisk')}</span><span class="brand-name">pulso.</span></div>`;
const btn = (act, label, cls = '', extra = '') => `<button class="btn ${cls}" data-act="${act}" ${extra}>${label}</button>`;
const eyebrow = () => `<p class="eyebrow">Hoy · ${short(new Date())}</p>`;
const head = (t, h, lead) => `<div>${t}<h1 tabindex="-1">${h}</h1>${lead ? `<p class="lead">${lead}</p>` : ''}</div>`;
const note = (cls, icon, txt) => `<div class="note ${cls}">${ic(icon, 18)}<p>${txt}</p></div>`;
const scoreCard = (e, lg) => `<div class="score ${lg ? 'lg' : ''}"><div class="tile">${e.score}<small>/10</small></div><div><b>${rangeOf(e.score).label}</b>${short(new Date(e.at))} · ${hm(new Date(e.at))}<br>Puntuación guardada</div></div>`;
const picker = (val, cls, label) => `<div><div class="big ${cls}">${String(val).replace('.', ',')}<small>/ 10</small></div><p class="rl ${cls}">${label}</p><div class="grid">${[1,2,3,4,5,6,7,8,9,10].map(n => `<button data-act="pick" data-v="${n}" class="${n === val ? 'on' : ''}" aria-pressed="${n === val}">${n}</button>`).join('')}</div><div class="ends"><span>1 · Muy difícil</span><span>10 · Excelente</span></div></div>`;
const recCard = (r, on) => `<button class="rec ${on ? 'on' : ''}" data-act="tog" data-id="${r.id}" role="checkbox" aria-checked="${on}"><div><span class="m">${ic(r.icon, 15)}${r.min} min · estimados</span><b>${r.name}</b><p>${r.desc}</p></div><span class="cb">${on ? ic('check', 15) : ''}</span></button>`;
function historyChart(rows) {
  const points = rows.slice(0, 30).map(([day, entry]) => ({date:historyDate(day), score:Number(entry.score)})).filter(point => Number.isFinite(point.score) && point.score >= 1 && point.score <= 10).reverse();
  if (!points.length) return '';
  const firstTime = points[0].date.getTime(), lastTime = points[points.length - 1].date.getTime(), timeSpan = lastTime - firstTime;
  const left = 44, right = 311, top = 22, bottom = 177;
  const x = point => left + (point.date.getTime() - firstTime) / (timeSpan || 1) * (right - left), y = score => bottom - (score - 1) / 9 * (bottom - top);
  const path = points.map((point, i) => `${i ? 'L' : 'M'}${x(point).toFixed(1)},${y(point.score).toFixed(1)}`).join(' ');
  const xTicks = timeSpan === 0 ? [{f:.5, date:points[0].date}] : [0,1].map(f => ({f, date:new Date(firstTime + timeSpan * f)}));
  const yTicks = [1,5,10].map(score => `<g><line x1="${left}" y1="${y(score)}" x2="${right}" y2="${y(score)}" class="chart-grid"/><text x="34" y="${y(score)+4}" text-anchor="end" class="chart-label">${score}</text></g>`).join('');
  const xLabels = xTicks.map(tick => `<text x="${timeSpan === 0 ? (left+right)/2 : left+(right-left)*tick.f}" y="201" text-anchor="${tick.f === 0 ? 'start' : tick.f === 1 ? 'end' : 'middle'}" class="chart-label">${tick.date.toLocaleDateString('es-AR',{day:'numeric',month:'short'}).replace('.', '')}</text>`).join('');
  const marks = points.map(point => `<circle cx="${x(point).toFixed(1)}" cy="${y(point.score).toFixed(1)}" r="5" class="chart-point"><title>${point.date.toLocaleDateString('es-AR',{day:'numeric',month:'long',year:'numeric'})}: ${point.score}/10</title></circle>`).join('');
  return `<div class="history-chart"><svg viewBox="0 0 320 216" role="img" aria-label="Gráfico de puntuaciones del 1 al 10 a lo largo de las fechas">${yTicks}<line x1="${left}" y1="${top}" x2="${left}" y2="${bottom}" class="chart-axis"/><line x1="${left}" y1="${bottom}" x2="${right}" y2="${bottom}" class="chart-axis"/><path d="${path}" class="chart-line"/>${marks}${xLabels}<text x="9" y="13" class="chart-unit">PUNTUACIÓN</text></svg></div>`;
}

const V = {
menu: () => ({back:'home', title:'Menú', html:`<div class="stack info-view">${head('<p class="eyebrow">CONOCÉ PULSO</p>', '¿Qué estás buscando?', 'Elegí una sección para conocer mejor la aplicación.') }<div class="menu-links"><button data-act="manual"><span>Manual de Usuario</span>${ic('arrow-right',18)}</button><button data-act="why"><span>Porqué elegirnos</span>${ic('arrow-right',18)}</button><button data-act="about"><span>ABOUT PULSO</span>${ic('arrow-right',18)}</button></div></div>`}),
manual: () => ({back:'menu', title:'Manual de Usuario', html:`<div class="stack info-view">${head('<p class="eyebrow">MANUAL DE USUARIO</p>', '¿Cómo funciona PULSO?', 'Un espacio sencillo para escucharte y acompañar tus días.') }<ol class="manual-list"><li><b>Elegí tu puntuación</b><p>Pensá cómo estuvo tu día y elegí un número del 1 al 10.</p></li><li><b>Leé las recomendaciones</b><p>Explorá las actividades sugeridas y elegí tus compromisos para el día siguiente. También podés no elegir ninguna.</p></li><li><b>Llevá un historial de tus días</b><p>Consultá tus puntuaciones anteriores en la sección «Historial».</p></li><li><b>Escribite a vos mismo</b><p>En «Mi espacio», escribí lo que quieras, como quieras. Guardar cartas es opcional.</p></li></ol></div>`}),
why: () => ({back:'menu', title:'Porqué elegirnos', html:`<div class="stack info-view">${head('<p class="eyebrow">PORQUÉ ELEGIRNOS</p>', 'Un espacio para tus días.', 'PULSO está pensada para esas personas cuyos cambios de humor hacen que algunos días sea más difícil escucharse y encontrar el propio equilibrio.') }<div class="info-copy"><p>Con una puntuación diaria podés reconocer cómo te sentís y mirar tu recorrido con el tiempo.</p><p>Las recomendaciones proponen pequeños gestos posibles para acompañar cada día, sin exigencias ni juicios. PULSO se adapta a vos: elegís qué hacer y qué querés guardar.</p></div></div>`}),
about: () => ({back:'menu', title:'ABOUT PULSO', html:`<div class="stack info-view">${head('<p class="eyebrow">ABOUT PULSO</p>', 'Hola, soy Estefanía.', 'Una persona con constantes altibajos emocionales en mi día a día.') }<div class="info-copy"><p>Decidí crear PULSO para poder llevar un registro de mis días y poder mejorarlos con pequeñas actividades.</p><p>Cualquier recomendación es bienvenida :)</p></div><div class="about-signature">Con cariño,<br><b>Estefanía</b></div></div>`}),
home: () => ({html: `<div class="stack"><div><p class="home-date">${cap(DW[new Date().getDay()])}, ${new Date().getDate()} de ${MF[new Date().getMonth()]}</p><h1 tabindex="-1">Un momento<br>para vos.</h1><p class="lead">No todos los días se sienten igual. Este espacio es para escucharte, sin juzgarte.</p></div><div class="ritual"><img src="assets/ritual-de-bienestar.png" alt="" onerror="this.remove()"><span class="chip">${ic('sun', 14)}Tu pausa de hoy</span></div><div><h2>¿Cómo estuvo tu día?</h2><p class="lead">Elegí una puntuación del 1 al 10 y descubrí pequeños gestos para mañana.</p><p class="benefit">${ic('heart', 16)}Un minuto para conectar con vos.</p></div></div><div><button class="btn" data-act="start">Puntuar mi día ${ic('arrow-right', 18)}</button><p class="priv">Tu bienestar, a tu ritmo.</p></div>`}),
space: () => {
  const letters = [...DB.letters].sort((a, b) => b.at.localeCompare(a.at));
  return {back:'home', title:'Mi espacio', html:`<div class="stack space-view">${head('<p class="eyebrow">UN ESPACIO PERSONAL</p>', 'Cartas para vos.', 'Escribí lo que tengas ganas. No hace falta compartirlo con nadie.')}${note('pink', 'heart', 'Tus cartas quedan guardadas solo en este dispositivo.')}${btn('compose-letter', 'Escribir una carta ' + ic('pencil', 18))}${letters.length ? `<div class="letter-list"><h2>Tus cartas</h2>${letters.map(letter => `<button class="letter-preview" data-act="read-letter" data-id="${esc(letter.id)}"><span>${new Date(letter.at).toLocaleDateString('es-AR',{day:'numeric',month:'long',year:'numeric'})}</span><p>${esc(letter.body).replace(/\n/g,' ')}</p><b>Leer carta ${ic('arrow-right', 16)}</b></button>`).join('')}</div>` : `<div class="letter-empty"><span>${ic('notebook-pen', 23)}</span><p>Cuando escribas una carta, va a quedar acá para que puedas volver a leerla.</p></div>`}</div>`};
},
composeLetter: () => ({back:'space', title:'Una carta para vos', html:`<div class="stack compose-view">${head('<p class="eyebrow">SIN PRISA, SIN JUICIOS</p>', '¿Qué te gustaría decirte?', 'Podés escribir lo que quieras, para leerlo cuando tengas ganas.') }<label class="sr-only" for="letter-body">Tu carta</label><textarea id="letter-body" class="letter-body" placeholder="Querido yo…" autofocus>${esc(S.letterDraft)}</textarea><p class="sm">Es opcional. Guardá solo lo que quieras conservar.</p><div class="acts">${btn('save-letter', 'Guardar mi carta ' + ic('arrow-right', 18))}${btn('space', 'Cancelar', 'ghost')}</div></div>`}),
readLetter: () => {
  const letter = DB.letters.find(item => item.id === S.letterId);
  if (!letter) return {back:'space', title:'Carta', html:`<div class="letter-empty"><p>Esta carta ya no está disponible.</p>${btn('space', 'Volver a Mi espacio', '', '')}</div>`};
  return {back:'space', title:'Tu carta', html:`<div class="stack read-letter"><div>${head('<p class="eyebrow">PARA VOS</p>', 'Un momento tuyo.', new Date(letter.at).toLocaleDateString('es-AR',{weekday:'long',day:'numeric',month:'long',year:'numeric'}))}<article class="letter-paper">${esc(letter.body)}</article></div><div class="acts">${btn('compose-letter', 'Escribir otra carta ' + ic('pencil', 18))}${btn('delete-letter', 'Borrar esta carta', 'ghost danger')}</div></div>`};
},
history: () => {
  const rows = Object.entries(DB.entries || {}).sort(([a], [b]) => b.localeCompare(a));
  const list = rows.map(([day, e]) => {
    const date = historyDate(day), r = rangeOf(e.score), commitments = (e.commit || []).map(id => ALL[id]?.name).filter(Boolean);
    return `<article class="history-entry"><div class="history-score">${e.score}<small>/10</small></div><div class="history-info"><b>${cap(DW[date.getDay()])} ${date.getDate()} de ${MF[date.getMonth()]}</b><span>${r.label} · ${hm(new Date(e.at))}</span>${e.note ? `<small class="history-note">${esc(e.note)}</small>` : ''}${commitments.length ? `<small>${commitments.length} ${commitments.length === 1 ? 'actividad elegida' : 'actividades elegidas'}</small>` : ''}</div><span class="history-range r${r.id}">${ic(r.icon, 19)}</span></article>`;
  }).join('');
  const chartMode = S.historyMode === 'chart';
  return {back:'home', title:'Historial', html: rows.length
    ? `<div class="stack history-view">${head('<p class="eyebrow">TUS REGISTROS</p>', 'Tu recorrido.', 'Un registro para mirar cómo van cambiando tus días, a tu ritmo.')}<div class="history-switch" role="group" aria-label="Cómo ver tu historial"><button data-act="history-mode" data-mode="list" aria-pressed="${!chartMode}" class="${!chartMode ? 'on' : ''}">${ic('notebook-pen',16)}Lista</button><button data-act="history-mode" data-mode="chart" aria-pressed="${chartMode}" class="${chartMode ? 'on' : ''}">${ic('calendar-days',16)}Gráfico</button></div><p class="history-count">${rows.length} ${rows.length === 1 ? 'día registrado' : 'días registrados'}</p>${chartMode ? `<section class="history-chart-card"><h2>Evolución de tus puntuaciones</h2><p class="sm">Cada punto es un día que registraste. Se muestran tus últimos 30 registros.</p>${historyChart(rows)}</section>` : `<div class="history-list">${list}</div>`}<p class="sm history-local">Tus registros se guardan en este dispositivo.</p></div>`
    : `<div class="history-empty">${ic('calendar-days', 34)}${head('<p class="eyebrow">TUS REGISTROS</p>', 'Tu historia empieza acá.', 'Cuando registres tu primera puntuación, la vas a encontrar en este espacio.')}${btn('start', 'Puntuar mi día ' + ic('arrow-right', 18))}</div>`};
},
pick: () => ({back:'home', title:'Tu día', html: `<div class="stack">${head(eyebrow(), '¿Qué número le pondrías a hoy?', 'Elegí el número que mejor refleje cómo te sentís. No hay respuestas correctas.')}${picker(S.pick, '', rangeOf(S.pick).label)}<div class="day-note-field"><label for="day-note">Una nota del día <span>(opcional)</span></label><input id="day-note" type="text" maxlength="20" value="${esc(S.noteDraft)}" placeholder="Ej.: Vi a mis amigxs"><small>${[...S.noteDraft].length}/20 caracteres</small></div>${note('', 'clock-3', 'Una puntuación por día. Podés modificarla hasta las 23:59 de hoy.')}</div><div class="acts">${btn('save', 'Guardar mi puntuación ' + ic('arrow-right', 18))}${btn('cancel', 'Cancelar', 'ghost')}</div>`}),
invalid: () => ({back:'pick', title:'Tu día', html: `<div class="stack s20">${head(eyebrow(), 'Probemos con un número entero.', `Recibimos ${String(S.bad).replace('.', ',')}. Elegí una de las opciones para continuar.`)}${note('err', 'circle-alert', 'La puntuación debe ser un número entero entre 1 y 10, inclusive. No se guardó ningún registro.')}${picker(S.bad, 'bad', 'Revisá tu puntuación').replace(/class="on"/, '')}</div><div class="acts">${btn('pick', 'Volver al selector', '', 'data-v="' + S.pick + '"')}${btn('cancel', 'Cancelar', 'ghost')}</div>`}),
error: () => ({back:'pick', title:'Tu día', html: `<div class="stack" style="gap:28px"><div class="badge p">${ic('cloud-off', 36)}</div>${head('<p class="eyebrow">No se pudo guardar</p>', 'Tu día cuenta.<br>El registro tendrá que esperar.', 'No pudimos guardar este cambio. Intentá de nuevo más tarde.')}${note('err', 'circle-alert', 'El cambio no se guardó. Si ya tenías una puntuación de hoy, sigue intacta.')}<div class="plan" style="gap:12px"><p class="eyebrow" style="color:var(--mut);font-size:11px">Cambio pendiente</p><div style="display:flex;justify-content:space-between;align-items:center">Puntuación elegida<b style="font:800 26px Manrope,Inter,system-ui,sans-serif">${S.pick} / 10</b></div><p class="sm">Podés volver al selector cuando quieras intentarlo otra vez.</p></div></div><div class="acts">${btn('pick', 'Volver al selector ' + ic('arrow-left', 18), '', 'data-v="' + S.pick + '"')}${btn('home', 'Volver al inicio', 'ghost')}</div>`}),
exists: () => { const e = today(); return {back:'home', title:'Tu día', html: `<div class="stack">${head(eyebrow(), 'Hoy ya te diste un momento.', 'Esta es tu puntuación de hoy. Si algo cambió, todavía podés actualizarla.')}${scoreCard(e, 1)}${note('cream', 'clock-3', 'Podés modificarla hasta las 23:59 de hoy. El cambio reemplaza tu puntuación, no crea otra.')}<div><h2>¿Querés modificarla?</h2><p class="lead">También podés mantener tu ${e.score} y volver a ver las recomendaciones que ya te asignamos.</p></div><div class="note" style="border:1px solid var(--bd);background:#fff;padding:16px;align-items:center"><span style="color:var(--mag)">${ic('bookmark-check', 22)}</span><p>Si la mantenés, tus recomendaciones no cambian.</p></div></div><div class="acts g10">${btn('modify', 'Modificar mi puntuación ' + ic('pencil', 18))}${btn('keep', 'Mantener y ver recomendaciones', 'out')}</div>`}; },
result: () => { const e = today(), r = rangeOf(e.score), n = S.sel.size, min = [...S.sel].reduce((s, id) => s + ALL[id].min, 0);
  const t = e.general ? ['Otra forma de cuidarte mañana.', `Hoy fue ${r.phrase}. Te proponemos gestos simples para seguir cuidándote.`, 'Pequeñas pausas para vos', 'Elegí lo que te sirva para mañana. También está bien no elegir.'] : [r.t, r.d, '¿Qué te llevás a mañana?', 'Elegí las actividades que quieras. Son sugerencias, no obligaciones.'];
  return {back:'home', title:'Tu resultado', html: `<div class="stack s20"><p class="saved">${ic('circle-check', 16)}Puntuación guardada</p>${head('', t[0], t[1])}${scoreCard(e)}${e.general ? note('cream', 'sparkles', 'No hay sugerencias nuevas para tu rango: no hay disponibles o ya las viste en los últimos 3 días. Estas son opciones generales de bienestar.') : ''}<div><h3 class="t">${t[2]}</h3><p class="sm" style="margin-top:7px">${t[3]}</p></div><div class="recs">${e.ids.map(id => recCard(ALL[id], S.sel.has(id))).join('')}</div></div><div><p class="sum">${n ? `${n} ${n > 1 ? 'actividades elegidas' : 'actividad elegida'} · ${min} min ${e.general ? 'para vos' : 'en total'}` : 'Elegí las que quieras o tocá «Ahora no»'}</p><div class="acts">${btn('confirm', 'Confirmar mis compromisos', '', n ? '' : 'disabled')}${btn('later', 'Ahora no', 'ghost')}</div></div>`}; },
done: () => { const e = today(), t = new Date(Date.now() + 864e5), N = ['', 'un pequeño gesto', 'dos pequeños gestos', 'tres pequeños gestos'][e.commit.length], min = e.commit.reduce((s, id) => s + ALL[id].min, 0);
  return {back:'home', title:'Para mañana', html: `<div class="stack"><div class="badge">${ic('check', 40)}</div>${head('<p class="eyebrow">Compromisos confirmados</p>', 'Mañana empieza<br>con algo bueno.', `Elegiste ${N} para cuidarte. Hacelo${e.commit.length > 1 ? 's' : ''} a tu manera, sin exigencias.`)}<div class="plan"><div class="d">${ic('calendar-days', 22)}<div><span>MAÑANA</span><b>${cap(DW[t.getDay()])} ${t.getDate()} de ${MF[t.getMonth()]} de ${t.getFullYear()}</b></div></div>${e.commit.map(id => `<div class="i"><i>${ic(ALL[id].icon, 19)}</i><div><b>${ALL[id].name}</b>${ALL[id].min} min estimados</div>${ic('check', 16)}</div>`).join('')}<div class="tot"><span>${e.commit.length} ${e.commit.length > 1 ? 'actividades' : 'actividad'}</span><b>${min} min para vos</b></div></div>${note('pink', 'heart', 'Tu puntuación de hoy sigue guardada. Gracias por darte este momento.')}</div>${btn('home', 'Volver al inicio')}`}; },
later: () => ({back:'home', title:'Tu día', html: `<div class="card"><p class="eyebrow" style="font-size:11px;letter-spacing:.8px">Después de «Ahora no»</p><h1 tabindex="-1" style="font-size:22px;letter-spacing:0;margin:0">Por hoy, está bien así.</h1><p class="sm">Tu ${today().score}/10 quedó guardado. No registramos compromisos para mañana. Gracias por escucharte.</p>${btn('home', 'Volver al inicio', 'out', 'style="height:44px;border:0;font-size:13px"')}</div>`})};

function render() {
  const v = V[S.screen](), menuButton = `<button class="menu-button" data-act="menu" aria-label="Abrir menú">${ic('menu', 24)}</button>`, actions = `<div class="bar-actions">${brand()}${menuButton}</div>`;
  const h = v.back ? `<header class="bar"><button class="back" data-act="back" aria-label="Volver">${ic('arrow-left')}</button><span class="bar-title">${v.title}</span>${actions}</header>` : `<header class="bar home-bar">${brand()}${menuButton}</header>`;
  $('#view').innerHTML = `${h}<main class="content">${v.html}</main>`;
  const tab = S.screen === 'history' ? 'history' : ['space','composeLetter','readLetter'].includes(S.screen) ? 'space' : 'home';
  $('#app-nav').innerHTML = `<button data-act="home" class="${tab === 'home' ? 'on' : ''}" ${tab === 'home' ? 'aria-current="page"' : ''}>${ic('house', 21)}Inicio</button><button data-act="history" class="${tab === 'history' ? 'on' : ''}" ${tab === 'history' ? 'aria-current="page"' : ''}>${ic('calendar-days', 21)}Historial</button><button data-act="space" class="${tab === 'space' ? 'on' : ''}" ${tab === 'space' ? 'aria-current="page"' : ''}>${ic('user-round', 21)}Mi espacio</button>`;
  $('#app-nav').hidden = false;
  const f = $('#view h1'); if (f) f.focus({preventScroll:true});
}
const go = s => { S.screen = s; render(); };
let tt; const toast = m => { const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tt); tt = setTimeout(() => t.classList.remove('on'), 2200); };
const A = {
 menu: () => go('menu'),
 manual: () => go('manual'),
 why: () => go('why'),
 about: () => go('about'),
 start: () => { if (today()) go('exists'); else { S.pick = 7; S.noteDraft = ''; go('pick'); } },
 history: () => go('history'),
 'history-mode': d => { S.historyMode = d.mode === 'chart' ? 'chart' : 'list'; render(); },
 space: () => go('space'),
 'compose-letter': () => go('composeLetter'),
 'read-letter': d => { S.letterId = d.id; go('readLetter'); },
 'save-letter': () => {
   const body = $('#letter-body').value.trim(); if (!body) return toast('Escribí algo antes de guardar la carta.');
   const letter = {id: `${Date.now()}-${Math.random().toString(36).slice(2,8)}`, body, at:new Date().toISOString()};
   DB.letters.push(letter); if (!persist()) { DB.letters.pop(); return toast('No se pudo guardar. Revisá el espacio disponible en el dispositivo.'); }
   S.letterDraft = ''; S.letterId = letter.id; go('readLetter');
 },
 'delete-letter': () => { if (!window.confirm('¿Querés borrar esta carta? No se puede recuperar.')) return; const i = DB.letters.findIndex(item => item.id === S.letterId); if (i < 0) return go('space'); const [letter] = DB.letters.splice(i, 1); if (!persist()) { DB.letters.splice(i, 0, letter); return toast('No se pudo borrar la carta. Intentá de nuevo.'); } S.letterId = null; go('space'); },
 pick: d => { S.pick = +d.v; S.screen === 'pick' ? render() : go('pick'); },
 save: () => { const val = S.pick;
   if (!Number.isInteger(val) || val < 1 || val > 10) { S.bad = val; return go('invalid'); }
   const day = key(new Date()), previous = DB.entries[day]; saveToday(val, S.noteDraft.trim());
   if (!persist()) { if (previous) DB.entries[day] = previous; else delete DB.entries[day]; return go('error'); }
   go('result'); },
 cancel: () => { toast('Podés volver cuando quieras.'); go('home'); },
 tog: d => { S.sel.has(d.id) ? S.sel.delete(d.id) : S.sel.add(d.id); render(); },
 confirm: () => { const e = today(), previous = e.commit; e.commit = [...S.sel]; if (!persist()) { e.commit = previous; return toast('No se pudieron guardar tus compromisos. Revisá el espacio disponible en el dispositivo.'); } go('done'); },
 later: () => { const e = today(), previous = e.commit; e.commit = []; if (!persist()) { e.commit = previous; return toast('No se pudo guardar el cambio. Revisá el espacio disponible en el dispositivo.'); } go('later'); },
 modify: () => { S.pick = today().score; S.noteDraft = today().note || ''; go('pick'); },
 keep: () => { S.sel = new Set(today().commit); go('result'); },
 back: () => go({invalid:'pick', error:'pick', composeLetter:'space', readLetter:'space', manual:'menu', why:'menu', about:'menu'}[S.screen] || 'home'),
 home: () => go('home'), soon: () => toast('Esta sección no forma parte del prototipo.')};
document.addEventListener('click', e => { const b = e.target.closest('[data-act]'); if (b && !b.disabled) A[b.dataset.act](b.dataset); });
document.addEventListener('input', e => {
  if (e.target.id === 'letter-body') S.letterDraft = e.target.value;
  if (e.target.id === 'day-note') { S.noteDraft = [...e.target.value].slice(0, 20).join(''); const count = document.querySelector('.day-note-field small'); if (count) count.textContent = `${[...S.noteDraft].length}/20 caracteres`; }
});
if ('serviceWorker' in navigator && location.protocol !== 'file:') navigator.serviceWorker.register('./sw.js').catch(() => {});

render();
})();
