// Prepara una carpeta estática para publicar PULSO en un hosting HTTPS.
const fs = require('node:fs');
const path = require('node:path');

const source = __dirname;
const output = path.join(source, 'dist');
const publicFiles = [
  'index.html', 'styles.css', 'app.js', 'manifest.webmanifest', 'sw.js',
  'assets/icon.svg', 'assets/icon-192.png', 'assets/icon-512.png',
  'assets/ritual-de-bienestar.png'
];

for (const relative of publicFiles) {
  const from = path.join(source, relative);
  const to = path.join(output, relative);
  if (!fs.existsSync(from)) throw new Error(`Falta un archivo necesario: ${relative}`);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
}

console.log(`Versión de publicación preparada en ${output}`);
